library(ggplot2)
attach(figure_2)

##option 1 ##
ggplot(figure_2, aes(y=`Mislabelling Relative Frequency (%)`, x=`Sustainable category`)) + 
  geom_bar(position="dodge", stat="identity")

attach(figure_3)
ggplot(figure_3, aes(y=`Mislabelling Relative Frequency (%)`, x=Source)) + 
  geom_bar(position="dodge", stat="identity")

attach(binomial_regression)
glm.fit <- glm(mislabelling ~ Source + `Sustainable category`, data = binomial_regression, family = binomial)
summary(glm.fit)
